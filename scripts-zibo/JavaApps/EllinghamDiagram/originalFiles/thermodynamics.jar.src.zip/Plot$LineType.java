public enum Plot$LineType
{
  Normal,  Circled;
  
  private Plot$LineType() {}
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Plot$LineType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */