public enum Plot$BoundMode
{
  Independent,  SameScale,  FixedAxis;
  
  private Plot$BoundMode() {}
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Plot$BoundMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */