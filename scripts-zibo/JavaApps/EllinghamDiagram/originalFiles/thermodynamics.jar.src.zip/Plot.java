import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import processing.core.PApplet;
import processing.core.PFont;

public class Plot
{
  Plot.BoundMode boundMode = Plot.BoundMode.Independent;
  PApplet applet;
  Plot.LineType lineType;
  public static final Plot.LineType Circled = Plot.LineType.Circled;
  public static final Plot.LineType Normal = Plot.LineType.Normal;
  public int xpos = 0;
  public int ypos = 0;
  public int xsize = 200;
  public int ysize = 200;
  boolean animating;
  int duration = 0;
  int[] destination;
  int frame;
  float xmax;
  float xmin;
  float ymax;
  float ymin;
  public int[] padding = { 0, 0, 0, 0 };
  public int bgColor = -3618616;
  public int bgColorPlot = -1;
  public ArrayList<Plot.Data> data = new ArrayList();
  float[] Xgrid;
  float[] Ygrid;
  public PFont font;
  public PFont smallFont;
  protected int xexp;
  protected int yexp;
  protected int exp;
  String xTitle;
  String yTitle;
  String title;
  boolean updated;
  boolean displayAxis;
  
  public Plot(PApplet paramPApplet, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.applet = paramPApplet;
    Font localFont = new Font("Helvetica", 0, 12);
    this.font = new PFont(localFont, true);
    localFont = new Font("Helvetica", 0, 11);
    this.smallFont = new PFont(localFont, true);
    this.xpos = paramInt1;
    this.ypos = paramInt2;
    this.xsize = paramInt3;
    this.ysize = paramInt4;
    this.updated = true;
  }
  
  public Plot(PApplet paramPApplet, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.applet = paramPApplet;
    this.font = paramPApplet.loadFont("Helvetica-12.vlw");
    this.smallFont = paramPApplet.loadFont("Helvetica-11.vlw");
    this.xpos = paramInt1;
    this.ypos = paramInt2;
    this.xsize = paramInt3;
    this.ysize = paramInt4;
    AddData(paramArrayOfFloat1, paramArrayOfFloat2);
    this.updated = true;
  }
  
  public void AddData(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
  {
    if (paramArrayOfFloat1 == null) {
      paramArrayOfFloat1 = new float[0];
    }
    if (paramArrayOfFloat2 == null) {
      paramArrayOfFloat2 = new float[0];
    }
    assert (paramArrayOfFloat1.length == paramArrayOfFloat2.length) : "data length does not match";
    this.data.add(new Plot.Data(paramArrayOfFloat1, paramArrayOfFloat2));
    UpdateBounds();
  }
  
  public void AddTag(String paramString)
  {
    int i = this.data.size() - 1;
    assert (i >= 0) : "No data in the plot";
    Plot.Data localData = (Plot.Data)this.data.get(i);
    localData.tag = paramString;
  }
  
  public void SetTag(int paramInt, String paramString)
  {
    assert ((paramInt >= 0) && (paramInt < this.data.size())) : "invalid index";
    Plot.Data localData = (Plot.Data)this.data.get(paramInt);
    localData.tag = paramString;
  }
  
  public void SetHidden(int paramInt, boolean paramBoolean)
  {
    assert ((paramInt >= 0) && (paramInt < this.data.size())) : "invalid index";
    Plot.Data localData = (Plot.Data)this.data.get(paramInt);
    localData.hidden = paramBoolean;
    this.updated = true;
  }
  
  public void HideAll()
  {
    Iterator localIterator = this.data.iterator();
    while (localIterator.hasNext())
    {
      Plot.Data localData = (Plot.Data)localIterator.next();
      localData.hidden = true;
    }
  }
  
  public void ShowAll()
  {
    Iterator localIterator = this.data.iterator();
    while (localIterator.hasNext())
    {
      Plot.Data localData = (Plot.Data)localIterator.next();
      localData.hidden = false;
    }
  }
  
  public String GetTags()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Iterator localIterator = this.data.iterator();
    while (localIterator.hasNext())
    {
      Plot.Data localData = (Plot.Data)localIterator.next();
      localStringBuffer.append(localData.tag);
      localStringBuffer.append("\n");
    }
    return localStringBuffer.toString();
  }
  
  public int size()
  {
    return this.data.size();
  }
  
  protected void UpdateBounds()
  {
    float f1 = Float.MIN_VALUE;
    float f2 = Float.MAX_VALUE;
    float f3 = Float.MIN_VALUE;
    float f4 = Float.MAX_VALUE;
    if (this.boundMode != Plot.BoundMode.FixedAxis)
    {
      Iterator localIterator = this.data.iterator();
      while (localIterator.hasNext())
      {
        Plot.Data localData = (Plot.Data)localIterator.next();
        if (this.boundMode == Plot.BoundMode.Independent)
        {
          f1 = Float.MIN_VALUE;
          f3 = Float.MIN_VALUE;
          f2 = Float.MAX_VALUE;
          f4 = Float.MAX_VALUE;
        }
        if ((localData.X == null) || (localData.Y == null))
        {
          float f6;
          for (f6 : localData.Xdata)
          {
            if (f6 > f1) {
              f1 = f6;
            }
            if (f6 < f2) {
              f2 = f6;
            }
          }
          for (f6 : localData.Ydata)
          {
            if (f6 > f3) {
              f3 = f6;
            }
            if (f6 < f4) {
              f4 = f6;
            }
          }
        }
        else
        {
          ??? = localData.X.iterator();
          float f5;
          while (((Iterator)???).hasNext())
          {
            f5 = ((Float)((Iterator)???).next()).floatValue();
            if (f5 > f1) {
              f1 = f5;
            }
            if (f5 < f2) {
              f2 = f5;
            }
          }
          ??? = localData.Y.iterator();
          while (((Iterator)???).hasNext())
          {
            f5 = ((Float)((Iterator)???).next()).floatValue();
            if (f5 > f3) {
              f3 = f5;
            }
            if (f5 < f4) {
              f4 = f5;
            }
          }
        }
        if (this.boundMode == Plot.BoundMode.Independent)
        {
          localData.Xmax = f1;
          localData.Xmin = f2;
          localData.Ymax = f3;
          localData.Ymin = f4;
        }
      }
      this.xmin = f2;
      this.xmax = f1;
      this.ymin = f4;
      this.ymax = f3;
    }
    if ((this.Xgrid != null) || (this.Ygrid != null)) {
      UpdateGrid();
    }
    this.updated = true;
  }
  
  public static float[] toFloat(Object[] paramArrayOfObject)
  {
    float[] arrayOfFloat = new float[paramArrayOfObject.length];
    for (int i = 0; i < paramArrayOfObject.length; i++)
    {
      assert ((paramArrayOfObject[i] instanceof Float)) : "invalid data";
      arrayOfFloat[i] = ((Float)paramArrayOfObject[i]).floatValue();
    }
    return arrayOfFloat;
  }
  
  public void UpdateData(int paramInt, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
  {
    assert ((paramInt >= 0) && (paramInt < this.data.size())) : ("invalid plot index - index should be less than " + this.data.size());
    if (paramArrayOfFloat1 == null) {
      paramArrayOfFloat1 = new float[0];
    }
    if (paramArrayOfFloat2 == null) {
      paramArrayOfFloat2 = new float[0];
    }
    assert (paramArrayOfFloat1.length == paramArrayOfFloat2.length) : "data length does not match";
    Plot.Data localData = (Plot.Data)this.data.get(paramInt);
    localData.Xdata = paramArrayOfFloat1;
    localData.Ydata = paramArrayOfFloat2;
    UpdateBounds();
    this.updated = true;
  }
  
  public void UpdateData(int paramInt, List<Float> paramList1, List<Float> paramList2)
  {
    assert ((paramInt >= 0) && (paramInt < this.data.size())) : ("invalid plot index - index should be less than " + this.data.size());
    assert ((paramList1 != null) && (paramList2 != null)) : "invalid data";
    assert (paramList1.size() == paramList2.size()) : "data length does not match";
    Plot.Data localData = (Plot.Data)this.data.get(paramInt);
    localData.X = paramList1;
    localData.Y = paramList2;
    UpdateBounds();
    this.updated = true;
  }
  
  protected boolean inside(float paramFloat1, float paramFloat2)
  {
    return (paramFloat1 >= this.xpos + this.padding[3]) && (paramFloat1 <= this.xpos + this.xsize - this.padding[1]) && (paramFloat2 >= this.ypos + this.padding[0]) && (paramFloat2 <= this.ypos + this.ysize - this.padding[2]);
  }
  
  protected float[] ClampLine(float[] paramArrayOfFloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int[] arrayOfInt = { this.xpos, this.ypos, this.xsize, this.ysize };
    this.xpos = paramInt1;
    this.ypos = paramInt2;
    this.xsize = paramInt3;
    this.ysize = paramInt4;
    float[] arrayOfFloat = ClampLine(paramArrayOfFloat);
    this.xpos = arrayOfInt[0];
    this.ypos = arrayOfInt[1];
    this.xsize = arrayOfInt[2];
    this.ysize = arrayOfInt[3];
    return arrayOfFloat;
  }
  
  protected float[] ClampLine(float[] paramArrayOfFloat)
  {
    assert (paramArrayOfFloat != null) : "invalid line";
    assert (paramArrayOfFloat.length == 4) : "invalide line";
    boolean bool1 = inside(paramArrayOfFloat[0], paramArrayOfFloat[1]);
    boolean bool2 = inside(paramArrayOfFloat[2], paramArrayOfFloat[3]);
    if ((!bool1) && (!bool2)) {
      return null;
    }
    if ((bool1) && (bool2)) {
      return paramArrayOfFloat;
    }
    if ((bool1) && (!bool2))
    {
      f1 = paramArrayOfFloat[0];
      paramArrayOfFloat[0] = paramArrayOfFloat[2];
      paramArrayOfFloat[2] = f1;
      f1 = paramArrayOfFloat[1];
      paramArrayOfFloat[1] = paramArrayOfFloat[3];
      paramArrayOfFloat[3] = f1;
    }
    float f1 = this.xpos + this.padding[3];
    float f2 = this.xpos + this.xsize - this.padding[1];
    float f3 = this.ypos + this.padding[0];
    float f4 = this.ypos + this.ysize - this.padding[2];
    float f5 = paramArrayOfFloat[2] - paramArrayOfFloat[0];
    float f6 = paramArrayOfFloat[3] - paramArrayOfFloat[1];
    float f7 = paramArrayOfFloat[0] * paramArrayOfFloat[3] - paramArrayOfFloat[1] * paramArrayOfFloat[2];
    if ((f7 >= 0.0F) && (f7 < 1.0E-10F)) {
      f7 = 1.0E-10F;
    }
    if ((f7 < 0.0F) && (f7 > -1.0E-10F)) {
      f7 = -1.0E-10F;
    }
    float f8 = (paramArrayOfFloat[3] - paramArrayOfFloat[1]) / f7;
    float f9 = (paramArrayOfFloat[0] - paramArrayOfFloat[2]) / f7;
    float f10;
    if (paramArrayOfFloat[0] < f1)
    {
      f10 = (f1 - paramArrayOfFloat[0]) / f5;
      paramArrayOfFloat[0] = f1;
      paramArrayOfFloat[1] = (paramArrayOfFloat[1] * (1.0F - f10) + paramArrayOfFloat[3] * f10);
    }
    if (paramArrayOfFloat[0] > f2)
    {
      f10 = (f2 - paramArrayOfFloat[0]) / f5;
      paramArrayOfFloat[0] = (this.xpos + this.xsize - this.padding[1]);
      paramArrayOfFloat[1] = (paramArrayOfFloat[1] * (1.0F - f10) + paramArrayOfFloat[3] * f10);
    }
    f5 = paramArrayOfFloat[2] - paramArrayOfFloat[0];
    f6 = paramArrayOfFloat[3] - paramArrayOfFloat[1];
    f7 = paramArrayOfFloat[0] * paramArrayOfFloat[3] - paramArrayOfFloat[1] * paramArrayOfFloat[2];
    if (f7 < 1.0E-10F) {
      f7 = 1.0E-10F;
    }
    f8 = (paramArrayOfFloat[3] - paramArrayOfFloat[1]) / f7;
    f9 = (paramArrayOfFloat[0] - paramArrayOfFloat[2]) / f7;
    if (paramArrayOfFloat[1] < f3)
    {
      f10 = (f3 - paramArrayOfFloat[1]) / f6;
      paramArrayOfFloat[0] = (paramArrayOfFloat[0] * (1.0F - f10) + paramArrayOfFloat[2] * f10);
      paramArrayOfFloat[1] = f3;
    }
    if (paramArrayOfFloat[1] > f4)
    {
      f10 = (f4 - paramArrayOfFloat[1]) / f6;
      paramArrayOfFloat[0] = (paramArrayOfFloat[0] * (1.0F - f10) + paramArrayOfFloat[2] * f10);
      paramArrayOfFloat[1] = f4;
    }
    return paramArrayOfFloat;
  }
  
  public void ForcePlot()
  {
    this.updated = true;
    ScribePlot();
  }
  
  public boolean ScribePlot()
  {
    if (!this.updated) {
      return false;
    }
    UpdateBounds();
    int i = this.xpos;
    int j = this.ypos;
    int k = this.xsize;
    int m = this.ysize;
    if (this.animating) {
      if (this.frame >= this.duration)
      {
        this.animating = false;
        i = this.xpos = this.destination[0];
        j = this.ypos = this.destination[1];
        k = this.xsize = this.destination[2];
        m = this.ysize = this.destination[3];
      }
      else
      {
        f1 = this.frame / this.duration;
        i = (int)(i * (1.0F - f1) + this.destination[0] * f1);
        j = (int)(j * (1.0F - f1) + this.destination[1] * f1);
        k = (int)(k * (1.0F - f1) + this.destination[2] * f1);
        m = (int)(m * (1.0F - f1) + this.destination[3] * f1);
        this.frame += 1;
      }
    }
    this.applet.noStroke();
    this.applet.fill(this.bgColor);
    this.applet.rect(i, j, k, m);
    this.applet.stroke(0);
    this.applet.fill(this.bgColorPlot);
    this.applet.rect(i + this.padding[3], j + this.padding[0], k - this.padding[1] - this.padding[3], m - this.padding[0] - this.padding[2]);
    float f1 = this.xmax;
    float f2 = this.xmin;
    float f3 = this.ymax;
    float f4 = this.ymin;
    this.applet.fill(0);
    this.applet.ellipseMode(3);
    Object localObject = this.data.iterator();
    float f8;
    while (((Iterator)localObject).hasNext())
    {
      Plot.Data localData = (Plot.Data)((Iterator)localObject).next();
      if (!localData.hidden)
      {
        this.applet.stroke(localData.PlotR, localData.PlotG, localData.PlotB);
        this.applet.fill(localData.PlotR, localData.PlotG, localData.PlotB);
        float[] arrayOfFloat1 = localData.Xdata;
        float[] arrayOfFloat2 = localData.Ydata;
        if (((localData.X != null) && (localData.Y != null)) || ((arrayOfFloat1.length > 1) && ((localData.X == null) || (localData.X.size() > 1))))
        {
          if (this.boundMode == Plot.BoundMode.Independent)
          {
            f1 = localData.Xmax;
            f2 = localData.Xmin;
            f3 = localData.Ymax;
            f4 = localData.Ymin;
          }
          f8 = (k - this.padding[1] - this.padding[3]) / (f1 - f2);
          float f9 = (m - this.padding[0] - this.padding[2]) / (f3 - f4);
          float f10 = i + this.padding[3];
          float f11 = j + this.padding[0];
          float f12;
          float f13;
          int i1;
          int i2;
          int i3;
          float f15;
          if ((localData.X == null) || (localData.Y == null))
          {
            f12 = (arrayOfFloat1[0] - f2) * f8 + f10;
            f13 = (f3 - arrayOfFloat2[0]) * f9 + f11;
            i1 = arrayOfFloat1.length > localData.numpoints ? localData.numpoints : arrayOfFloat1.length;
            i2 = (arrayOfFloat1.length - 1) / (i1 - 1);
            i3 = i2 - localData.offset % i2;
            for (;;)
            {
              if (i3 >= arrayOfFloat1.length) {
                i3 = arrayOfFloat1.length - 1;
              }
              if (localData.gradation)
              {
                int i4 = localData.getColor(i3);
                this.applet.stroke(i4);
                this.applet.fill(i4);
              }
              float f14 = (arrayOfFloat1[i3] - f2) * f8 + f10;
              f15 = (f3 - arrayOfFloat2[i3]) * f9 + f11;
              float[] arrayOfFloat3 = { f12, f13, f14, f15 };
              arrayOfFloat3 = ClampLine(arrayOfFloat3, i, j, k, m);
              if (arrayOfFloat3 != null) {
                this.applet.line(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2], arrayOfFloat3[3]);
              }
              f12 = f14;
              f13 = f15;
              if ((i3 < arrayOfFloat1.length - 1) && (this.lineType == Plot.LineType.Circled) && (inside(f14, f15))) {
                this.applet.ellipse(f14, f15, 4.0F, 4.0F);
              }
              if (i3 == arrayOfFloat1.length - 1) {
                break;
              }
              i3 += i2;
            }
          }
          else
          {
            f12 = (((Float)localData.X.get(0)).floatValue() - f2) * f8 + f10;
            f13 = (f3 - ((Float)localData.Y.get(0)).floatValue()) * f9 + f11;
            i1 = localData.X.size() > localData.numpoints ? localData.numpoints : localData.X.size();
            i2 = 0;
            i3 = (localData.X.size() - 1) / (i1 - 1);
            int i5 = i3 - localData.offset % i3;
            for (;;)
            {
              if (i5 >= localData.X.size()) {
                i5 = localData.X.size() - 1;
              }
              f15 = ((Float)localData.X.get(i5)).floatValue();
              float f16 = ((Float)localData.Y.get(i5)).floatValue();
              if (localData.gradation)
              {
                int i6 = localData.getColor(i5);
                this.applet.stroke(i6);
                this.applet.fill(i6);
              }
              float f17 = (f15 - f2) * f8 + f10;
              float f18 = (f3 - f16) * f9 + f11;
              float[] arrayOfFloat4 = { f12, f13, f17, f18 };
              arrayOfFloat4 = ClampLine(arrayOfFloat4, i, j, k, m);
              if (arrayOfFloat4 != null) {
                this.applet.line(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2], arrayOfFloat4[3]);
              }
              f12 = f17;
              f13 = f18;
              if ((this.lineType == Plot.LineType.Circled) && (i5 < localData.X.size() - 1) && (inside(f17, f18))) {
                this.applet.ellipse(f17, f18, 4.0F, 4.0F);
              }
              if (i5 == localData.X.size() - 1) {
                break;
              }
              i5 += i3;
            }
          }
        }
      }
    }
    this.applet.stroke(0);
    this.applet.fill(0);
    if (this.font != null) {
      this.applet.textFont(this.font, 12.0F);
    }
    if (((this.Xgrid != null) || (this.Ygrid != null)) && ((this.data.size() > 0) || (this.boundMode == Plot.BoundMode.FixedAxis)))
    {
      this.applet.textFont(this.font, 12.0F);
      if (this.boundMode == Plot.BoundMode.Independent)
      {
        localObject = (Plot.Data)this.data.get(0);
        f1 = ((Plot.Data)localObject).Xmax;
        f2 = ((Plot.Data)localObject).Xmin;
        f3 = ((Plot.Data)localObject).Ymax;
        f4 = ((Plot.Data)localObject).Ymin;
      }
      float f5;
      float f6;
      float f7;
      int n;
      String str;
      if (this.Xgrid != null)
      {
        f5 = i + this.padding[3];
        f6 = (k - this.padding[1] - this.padding[3]) / (f1 - f2);
        f7 = j + m - this.padding[2];
        for (n = 0; n < this.Xgrid.length; n++)
        {
          f8 = (this.Xgrid[n] - f2) * f6 + f5;
          this.applet.line(f8, f7, f8, f7 - 5.0F);
          if ((this.xexp > 0) && (this.xexp <= 3)) {
            str = String.format("%d", new Object[] { Integer.valueOf(Math.round(this.Xgrid[n])) });
          } else {
            str = String.format("%.1f", new Object[] { Float.valueOf(this.Xgrid[n] / pow(10.0F, this.xexp)) });
          }
          this.applet.textAlign(3, 101);
          this.applet.text(str, f8 - 18.0F, f7 + 5.0F, 36.0F, 15.0F);
        }
        if ((this.xexp < 0) || (this.xexp > 3))
        {
          this.applet.textAlign(39, 101);
          this.applet.text("*10", i + k - this.padding[1] - 20, j + m - this.padding[2] + 25, 20.0F, 25.0F);
          this.applet.textAlign(37, 101);
          this.applet.text(String.format("%d", new Object[] { Integer.valueOf(this.xexp) }), i + k - this.padding[1], j + m - this.padding[2] + 20, 25.0F, 25.0F);
        }
      }
      if (this.Ygrid != null)
      {
        f5 = j + this.padding[0];
        f6 = (m - this.padding[0] - this.padding[2]) / (f3 - f4);
        f7 = i + this.padding[3];
        for (n = 0; n < this.Ygrid.length; n++)
        {
          f8 = (f3 - this.Ygrid[n]) * f6 + f5;
          this.applet.line(f7, f8, f7 + 5.0F, f8);
          if ((this.yexp > 0) && (this.yexp <= 4)) {
            str = String.format("%d", new Object[] { Integer.valueOf(Math.round(this.Ygrid[n])) });
          } else {
            str = String.format("%.1f", new Object[] { Float.valueOf(this.Ygrid[n] / pow(10.0F, this.yexp)) });
          }
          this.applet.textAlign(39, 3);
          this.applet.text(str, f7 - 40.0F, f8 - 10.0F, 36.0F, 20.0F);
        }
        if ((this.yexp < 0) || (this.yexp > 4))
        {
          this.applet.textAlign(39, 102);
          this.applet.text("*10", i + this.padding[3] - 60, j + 5, 25.0F, 25.0F);
          this.applet.textAlign(37, 102);
          this.applet.text(String.format("%d", new Object[] { Integer.valueOf(this.yexp) }), i + this.padding[3] - 35, j, 25.0F, 25.0F);
        }
      }
    }
    this.applet.textAlign(3);
    if (this.title != null) {
      this.applet.text(this.title, i + this.padding[3], j + 5, k - this.padding[1] - this.padding[3], this.padding[0] - 5);
    }
    if (this.xTitle != null) {
      this.applet.text(this.xTitle, i + this.padding[3], j + m - this.padding[2] + 25, k - this.padding[1] - this.padding[3], this.padding[2] - 25);
    }
    if (this.yTitle != null)
    {
      this.applet.pushMatrix();
      this.applet.rotate(-1.5707964F);
      this.applet.translate(-j * 2 - m, 0.0F);
      this.applet.text(this.yTitle, j + this.padding[2], i + 3, m - this.padding[0] - this.padding[2], 25.0F);
      this.applet.popMatrix();
    }
    this.updated = false;
    return true;
  }
  
  public void Color(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = this.data.size() - 1;
    assert (i >= 0) : "No data in the plot";
    Plot.Data localData = (Plot.Data)this.data.get(i);
    localData.PlotR = paramInt1;
    localData.PlotG = paramInt2;
    localData.PlotB = paramInt3;
    this.updated = true;
  }
  
  public void Color(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    assert ((paramInt1 >= 0) && (paramInt1 < this.data.size())) : ("Invalid index - should be less than " + this.data.size());
    Plot.Data localData = (Plot.Data)this.data.get(paramInt1);
    localData.PlotR = paramInt2;
    localData.PlotG = paramInt3;
    localData.PlotB = paramInt4;
    this.updated = true;
  }
  
  public void Gradation(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = this.data.size() - 1;
    assert (i >= 0) : "No data in the plot";
    Plot.Data localData = (Plot.Data)this.data.get(i);
    localData.gradation = true;
    localData.GradR = paramInt1;
    localData.GradG = paramInt2;
    localData.GradB = paramInt3;
    this.updated = true;
  }
  
  public void Gradation(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    assert ((paramInt1 >= 0) && (paramInt1 < this.data.size())) : ("Invalid index - should be less than " + this.data.size());
    Plot.Data localData = (Plot.Data)this.data.get(paramInt1);
    localData.gradation = true;
    localData.GradR = paramInt2;
    localData.GradG = paramInt3;
    localData.GradB = paramInt4;
    this.updated = true;
  }
  
  public static float pow(float paramFloat, int paramInt)
  {
    float f = 1.0F;
    if (paramInt < 0) {
      return 1.0F / pow(paramFloat, -paramInt);
    }
    while (paramInt != 0)
    {
      if ((paramInt & 0x1) != 0) {
        f *= paramFloat;
      }
      paramInt >>= 1;
      paramFloat *= paramFloat;
    }
    return f;
  }
  
  protected float[] MakeGrid(float paramFloat1, float paramFloat2)
  {
    float f1 = paramFloat2 - paramFloat1;
    if (f1 <= 1.0E-20D) {
      return null;
    }
    float f2 = (float)(Math.log(f1) / Math.log(10.0D));
    this.exp = ((int)Math.floor(f2));
    float f3 = f2 - this.exp;
    float f4 = pow(10.0F, this.exp);
    if (f3 < 0.2F) {
      f4 *= 0.2F;
    } else if (f3 < 0.5F) {
      f4 *= 0.5F;
    }
    float f5 = (float)Math.floor(paramFloat1 / f4) * f4;
    float f6 = (float)Math.ceil(paramFloat2 / f4) * f4;
    int i = Math.round((f6 - f5) / f4) - 1;
    if (f5 >= paramFloat1 - f1 * 1.0E-4D) {
      i++;
    }
    if (f6 <= paramFloat2 + f1 * 1.0E-4D) {
      i++;
    }
    float[] arrayOfFloat = new float[i];
    int j = 0;
    if (f5 >= paramFloat1 - f1 * 1.0E-4D) {
      arrayOfFloat[(j++)] = paramFloat1;
    } else {
      f5 += f4;
    }
    while (j < i)
    {
      arrayOfFloat[j] = (f5 + j * f4);
      j++;
    }
    if (f6 <= paramFloat2 + f1 * 1.0E-4D) {
      arrayOfFloat[(i - 1)] = paramFloat2;
    }
    return arrayOfFloat;
  }
  
  public void ShowAxis()
  {
    this.displayAxis = true;
    UpdatePaddings();
    UpdateGrid();
  }
  
  protected void UpdatePaddings()
  {
    int[] arrayOfInt = { 0, 0, 0, 0 };
    if (this.displayAxis)
    {
      arrayOfInt[0] += 10;
      arrayOfInt[1] += 20;
      arrayOfInt[2] += 40;
      arrayOfInt[3] += 40;
    }
    if (this.title != null) {
      arrayOfInt[0] += 15;
    }
    if (this.xTitle != null) {
      arrayOfInt[2] += 15;
    }
    if (this.yTitle != null) {
      arrayOfInt[3] += 15;
    }
    this.padding = arrayOfInt;
  }
  
  public void UpdateGrid()
  {
    float f1 = this.xmax;
    float f2 = this.xmin;
    float f3 = this.ymax;
    float f4 = this.ymin;
    if ((this.data.size() == 0) && (this.boundMode != Plot.BoundMode.FixedAxis)) {
      return;
    }
    if (this.boundMode == Plot.BoundMode.Independent)
    {
      Plot.Data localData = (Plot.Data)this.data.get(0);
      f1 = localData.Xmax;
      f2 = localData.Xmin;
      f3 = localData.Ymax;
      f4 = localData.Ymin;
    }
    this.Xgrid = MakeGrid(f2, f1);
    this.xexp = this.exp;
    this.Ygrid = MakeGrid(f4, f3);
    this.yexp = this.exp;
    this.updated = true;
  }
  
  public void SetFont(PFont paramPFont)
  {
    this.font = paramPFont;
    this.updated = true;
  }
  
  public void SetAxis(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    assert ((paramFloat1 <= paramFloat2) && (paramFloat3 <= paramFloat4)) : "invalid values";
    this.boundMode = Plot.BoundMode.FixedAxis;
    ShowAxis();
    this.xmin = paramFloat1;
    this.xmax = paramFloat2;
    this.ymin = paramFloat3;
    this.ymax = paramFloat4;
    UpdateGrid();
  }
  
  public void SetLineType(Plot.LineType paramLineType)
  {
    this.lineType = paramLineType;
    this.updated = true;
  }
  
  public void SetXTitle(String paramString)
  {
    this.xTitle = paramString;
    UpdatePaddings();
    this.updated = true;
  }
  
  public void SetYTitle(String paramString)
  {
    this.yTitle = paramString;
    UpdatePaddings();
    this.updated = true;
  }
  
  public void SetTitle(String paramString)
  {
    this.title = paramString;
    UpdatePaddings();
    this.updated = true;
  }
  
  public Plot.Data GetData(int paramInt)
  {
    return (Plot.Data)this.data.get(paramInt);
  }
  
  public void Animate(int[] paramArrayOfInt, int paramInt)
  {
    this.destination = paramArrayOfInt;
    this.duration = paramInt;
    this.frame = 0;
    this.animating = true;
  }
  
  public void SetNumPoints(int paramInt)
  {
    Iterator localIterator = this.data.iterator();
    while (localIterator.hasNext())
    {
      Plot.Data localData = (Plot.Data)localIterator.next();
      localData.numpoints = paramInt;
    }
  }
  
  public class Data
  {
    float Xmax;
    float Xmin;
    float Ymax;
    float Ymin;
    float[] Xdata;
    float[] Ydata;
    List<Float> X;
    List<Float> Y;
    int PlotR;
    int PlotG;
    int PlotB;
    int GradR;
    int GradG;
    int GradB;
    String tag;
    boolean hidden;
    boolean gradation;
    int numpoints = 1000;
    int offset = 0;
    
    public Data(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
    {
      this.Xdata = paramArrayOfFloat1;
      this.Ydata = paramArrayOfFloat2;
      this.PlotR = (this.PlotG = this.PlotB = 0);
      this.GradR = (this.GradG = this.GradB = 0);
      this.X = (this.Y = null);
      this.Xmax = (this.Ymax = Float.MIN_VALUE);
      this.Xmin = (this.Ymin = Float.MAX_VALUE);
      this.tag = null;
      this.hidden = false;
      this.gradation = false;
    }
    
    public int getColor(int paramInt)
    {
      int i = this.X == null ? this.Xdata.length : this.X.size();
      if (i == 1) {
        i = 2;
      }
      float f = paramInt / (i - 1);
      int j = (int)(this.GradR * (1.0F - f) + this.PlotR * f);
      int k = (int)(this.GradG * (1.0F - f) + this.PlotG * f);
      int m = (int)(this.GradB * (1.0F - f) + this.PlotB * f);
      return 0xFF000000 | j << 16 | k << 8 | m;
    }
  }
  
  public static enum LineType
  {
    Normal,  Circled;
    
    private LineType() {}
  }
  
  public static enum BoundMode
  {
    Independent,  SameScale,  FixedAxis;
    
    private BoundMode() {}
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Plot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */