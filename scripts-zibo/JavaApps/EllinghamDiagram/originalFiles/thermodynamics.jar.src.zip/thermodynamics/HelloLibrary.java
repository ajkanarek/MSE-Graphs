package thermodynamics;

import java.io.PrintStream;
import processing.core.PApplet;

public class HelloLibrary
{
  PApplet myParent;
  int myVariable = 0;
  public static final String VERSION = "0.1.1";
  
  public HelloLibrary(PApplet paramPApplet)
  {
    this.myParent = paramPApplet;
    welcome();
  }
  
  private void welcome()
  {
    System.out.println("thermodynamics 0.1.1");
  }
  
  public String sayHello()
  {
    return "hello library.";
  }
  
  public static String version()
  {
    return "0.1.1";
  }
  
  public void setVariable(int paramInt1, int paramInt2)
  {
    this.myVariable = (paramInt1 + paramInt2);
  }
  
  public int getVariable()
  {
    return this.myVariable;
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/thermodynamics/HelloLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */