package thermodynamics;

public class FFT
{
  public static float[] fft(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null) {
      return null;
    }
    int i = (paramArrayOfFloat.length - 1) / 2;
    return four1(paramArrayOfFloat, i, 1);
  }
  
  public static float[] four1(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
  {
    int i = paramInt1 << 1;
    int m = 1;
    float f7;
    int k;
    for (int i1 = 1; i1 < i; i1 += 2)
    {
      if (m > i1)
      {
        f7 = paramArrayOfFloat[m];
        paramArrayOfFloat[m] = paramArrayOfFloat[i1];
        paramArrayOfFloat[i1] = f7;
        f7 = 0.0F;
        f7 = paramArrayOfFloat[(m + 1)];
        paramArrayOfFloat[(m + 1)] = paramArrayOfFloat[(i1 + 1)];
        paramArrayOfFloat[(i1 + 1)] = f7;
        f7 = 0.0F;
      }
      k = i >> 1;
      while ((k >= 2) && (m > k))
      {
        m -= k;
        k >>= 1;
      }
      m += k;
    }
    int n;
    for (int j = 2; i > j; j = n)
    {
      n = j << 1;
      float f6 = paramInt2 * (6.2831855F / j);
      float f1 = (float)Math.sin(0.5D * f6);
      float f3 = -2.0F * f1 * f1;
      float f4 = (float)Math.sin(f6);
      float f2 = 1.0F;
      float f5 = 0.0F;
      for (k = 1; k < j; k += 2)
      {
        i1 = k;
        while (i1 <= i)
        {
          m = i1 + j;
          f7 = f2 * paramArrayOfFloat[m] - f5 * paramArrayOfFloat[(m + 1)];
          float f8 = f2 * paramArrayOfFloat[(m + 1)] + f5 * paramArrayOfFloat[m];
          paramArrayOfFloat[i1] -= f7;
          paramArrayOfFloat[(i1 + 1)] -= f8;
          paramArrayOfFloat[i1] += f7;
          paramArrayOfFloat[(i1 + 1)] += f8;
          i1 += n;
        }
        f2 = (f1 = f2) * f3 - f5 * f4 + f2;
        f5 = f5 * f3 + f1 * f4 + f5;
      }
    }
    return paramArrayOfFloat;
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/thermodynamics/FFT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */