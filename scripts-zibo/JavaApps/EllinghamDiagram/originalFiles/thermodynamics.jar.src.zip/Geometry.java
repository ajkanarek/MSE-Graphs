public class Geometry
{
  public static float[] intersection(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
  {
    float f1 = paramFloat3 - paramFloat1;
    float f2 = paramFloat4 - paramFloat2;
    float f3 = paramFloat7 - paramFloat5;
    float f4 = paramFloat8 - paramFloat6;
    float f5 = paramFloat5 - paramFloat3;
    float f6 = paramFloat6 - paramFloat4;
    float f7 = paramFloat7 - paramFloat3;
    float f8 = paramFloat8 - paramFloat4;
    float f9 = paramFloat1 - paramFloat7;
    float f10 = paramFloat2 - paramFloat8;
    float f11 = paramFloat3 - paramFloat7;
    float f12 = paramFloat4 - paramFloat8;
    if (outer(f1, f2, f5, f6) * outer(f1, f2, f7, f8) >= 0.0F) {
      return null;
    }
    if (outer(f3, f4, f9, f10) * outer(f3, f4, f11, f12) >= 0.0F) {
      return null;
    }
    if ((paramFloat1 - paramFloat3) * (paramFloat6 - paramFloat8) - (paramFloat2 - paramFloat4) * (paramFloat5 - paramFloat7) == 0.0F) {
      return null;
    }
    float f13 = ((paramFloat1 * paramFloat4 - paramFloat2 * paramFloat3) * (paramFloat5 - paramFloat7) - (paramFloat1 - paramFloat3) * (paramFloat5 * paramFloat8 - paramFloat6 * paramFloat7)) / ((paramFloat1 - paramFloat3) * (paramFloat6 - paramFloat8) - (paramFloat2 - paramFloat4) * (paramFloat5 - paramFloat7));
    float f14 = ((paramFloat1 * paramFloat4 - paramFloat2 * paramFloat3) * (paramFloat6 - paramFloat8) - (paramFloat2 - paramFloat4) * (paramFloat5 * paramFloat8 - paramFloat6 * paramFloat7)) / ((paramFloat1 - paramFloat3) * (paramFloat6 - paramFloat8) - (paramFloat2 - paramFloat4) * (paramFloat5 - paramFloat7));
    float[] arrayOfFloat = { f13, f14 };
    return arrayOfFloat;
  }
  
  public static float outer(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    return paramFloat1 * paramFloat4 - paramFloat3 * paramFloat2;
  }
  
  public static int Color(float paramFloat)
  {
    if (paramFloat < 0.0F) {
      paramFloat = 0.0F;
    }
    if (paramFloat > 1.0F) {
      paramFloat = 1.0F;
    }
    if (paramFloat < 0.2D)
    {
      i = (int)(paramFloat * 5.0F * 255.0F);
      return 0xFF000000 | i;
    }
    if (paramFloat < 0.4D)
    {
      i = (int)((paramFloat - 0.2D) * 5.0D * 255.0D);
      return 0xFF0000FF | i << 8;
    }
    if (paramFloat < 0.6D)
    {
      i = (int)((0.6D - paramFloat) * 5.0D * 255.0D);
      return 0xFF00FF00 | i;
    }
    if (paramFloat < 0.8D)
    {
      i = (int)((paramFloat - 0.6D) * 5.0D * 255.0D);
      return 0xFF00FF00 | i << 16;
    }
    int i = (int)((1.0D - paramFloat) * 5.0D * 255.0D);
    return 0xFFFF0000 | i << 8;
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Geometry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */