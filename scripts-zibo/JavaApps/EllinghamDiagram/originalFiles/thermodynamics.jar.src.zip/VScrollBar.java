import processing.core.PApplet;

public class VScrollBar
{
  int swidth;
  int sheight;
  int xpos;
  int ypos;
  float spos;
  float newspos;
  int sposMin;
  int sposMax;
  int loose;
  boolean over;
  boolean locked;
  float ratio;
  PApplet applet;
  
  public VScrollBar(PApplet paramPApplet, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.applet = paramPApplet;
    this.swidth = paramInt3;
    this.sheight = paramInt4;
    int i = paramInt4 - paramInt3;
    this.ratio = (1.0F / i);
    this.xpos = paramInt1;
    this.ypos = paramInt2;
    this.spos = (this.ypos + this.sheight / 2 - this.swidth / 2);
    this.newspos = this.spos;
    this.sposMin = this.ypos;
    this.sposMax = (this.ypos + this.sheight - this.swidth);
    this.loose = 2;
  }
  
  public VScrollBar(PApplet paramPApplet, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this.applet = paramPApplet;
    this.swidth = paramInt3;
    this.sheight = paramInt4;
    int i = paramInt4 - paramInt3;
    this.ratio = (1.0F / i);
    this.xpos = paramInt1;
    this.ypos = paramInt2;
    this.spos = (this.ypos + this.sheight / 2 - this.swidth / 2);
    this.newspos = this.spos;
    this.sposMin = this.ypos;
    this.sposMax = (this.ypos + this.sheight - this.swidth);
    this.loose = paramInt5;
  }
  
  public void update()
  {
    if (over()) {
      this.over = true;
    } else {
      this.over = false;
    }
    if ((this.applet.mousePressed) && (this.over)) {
      this.locked = true;
    }
    if (!this.applet.mousePressed) {
      this.locked = false;
    }
    if (this.locked) {
      this.newspos = PApplet.constrain(this.applet.mouseY - this.swidth / 2, this.sposMin, this.sposMax);
    }
    if (PApplet.abs(this.newspos - this.spos) > 1.0F) {
      this.spos += (this.newspos - this.spos) / this.loose;
    }
  }
  
  public int constrain(int paramInt1, int paramInt2, int paramInt3)
  {
    return PApplet.min(PApplet.max(paramInt1, paramInt2), paramInt3);
  }
  
  public boolean over()
  {
    return (this.applet.mouseX > this.xpos) && (this.applet.mouseX < this.xpos + this.swidth) && (this.applet.mouseY > this.ypos) && (this.applet.mouseY < this.ypos + this.sheight);
  }
  
  public void display()
  {
    this.applet.fill(255);
    this.applet.rect(this.xpos, this.ypos, this.swidth, this.sheight);
    if ((this.over) || (this.locked)) {
      this.applet.fill(150.0F, 0.0F, 0.0F);
    } else {
      this.applet.fill(200.0F, 200.0F, 200.0F);
    }
    this.applet.rect(this.xpos, this.spos, this.swidth, this.swidth);
  }
  
  public float getPos()
  {
    return 1.0F - (this.spos - this.ypos) * this.ratio;
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/VScrollBar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */