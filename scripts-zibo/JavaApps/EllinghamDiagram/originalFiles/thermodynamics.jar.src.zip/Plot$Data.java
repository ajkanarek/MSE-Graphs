import java.util.List;

public class Plot$Data
{
  float Xmax;
  float Xmin;
  float Ymax;
  float Ymin;
  float[] Xdata;
  float[] Ydata;
  List<Float> X;
  List<Float> Y;
  int PlotR;
  int PlotG;
  int PlotB;
  int GradR;
  int GradG;
  int GradB;
  String tag;
  boolean hidden;
  boolean gradation;
  int numpoints = 1000;
  int offset = 0;
  
  public Plot$Data(Plot paramPlot, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
  {
    this.Xdata = paramArrayOfFloat1;
    this.Ydata = paramArrayOfFloat2;
    this.PlotR = (this.PlotG = this.PlotB = 0);
    this.GradR = (this.GradG = this.GradB = 0);
    this.X = (this.Y = null);
    this.Xmax = (this.Ymax = Float.MIN_VALUE);
    this.Xmin = (this.Ymin = Float.MAX_VALUE);
    this.tag = null;
    this.hidden = false;
    this.gradation = false;
  }
  
  public int getColor(int paramInt)
  {
    int i = this.X == null ? this.Xdata.length : this.X.size();
    if (i == 1) {
      i = 2;
    }
    float f = paramInt / (i - 1);
    int j = (int)(this.GradR * (1.0F - f) + this.PlotR * f);
    int k = (int)(this.GradG * (1.0F - f) + this.PlotG * f);
    int m = (int)(this.GradB * (1.0F - f) + this.PlotB * f);
    return 0xFF000000 | j << 16 | k << 8 | m;
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Plot$Data.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */