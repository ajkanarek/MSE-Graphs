import java.awt.Font;
import java.util.HashMap;
import java.util.Map;
import processing.core.PApplet;
import processing.core.PFont;

public class TextLabel
{
  PApplet applet;
  String str;
  int posX;
  int posY;
  int alignX;
  int alignY;
  PFont normal;
  PFont small;
  float height;
  Map<Character, Float> width;
  float sizeX;
  float sizeY;
  float fontSize;
  float smallSize;
  float offsetX;
  float offsetY;
  float rotation;
  
  public TextLabel(PApplet paramPApplet, String paramString)
  {
    this.applet = paramPApplet;
    this.str = paramString;
    this.posX = -1;
    this.posY = -1;
    SetFont("Helvetica", 12);
    SetAlign(3, 3);
  }
  
  public TextLabel(PApplet paramPApplet, String paramString, int paramInt1, int paramInt2)
  {
    this.applet = paramPApplet;
    this.str = paramString;
    this.posX = paramInt1;
    this.posY = paramInt2;
    SetFont("Helvetica", 12);
    SetAlign(3, 3);
  }
  
  public void SetFont(String paramString, int paramInt)
  {
    this.fontSize = paramInt;
    Font localFont = new Font(paramString, 0, paramInt);
    this.normal = new PFont(localFont, true);
    this.smallSize = (paramInt * 11 / 12);
    localFont = new Font(paramString, 0, Math.round(this.smallSize));
    this.small = new PFont(localFont, true);
    this.height = (this.normal.ascent() + this.normal.descent());
    this.sizeY = (this.height * this.fontSize);
    this.sizeX = 0.0F;
    this.width = new HashMap();
    for (int i = 0; i < this.str.length(); i++)
    {
      char c = this.str.charAt(i);
      if (!this.width.containsKey(Character.valueOf(c))) {
        this.width.put(Character.valueOf(c), Float.valueOf(this.normal.width(c)));
      }
      if ((c == '^') || (c == '_')) {
        for (;;)
        {
          i++;
          if ((i >= this.str.length()) || ((c = this.str.charAt(i)) == ' ')) {
            break;
          }
          if (!this.width.containsKey(Character.valueOf(c))) {
            this.width.put(Character.valueOf(c), Float.valueOf(this.normal.width(c)));
          }
          this.sizeX += ((Float)this.width.get(Character.valueOf(c))).floatValue() * this.smallSize;
        }
      }
      this.sizeX += ((Float)this.width.get(Character.valueOf(c))).floatValue() * paramInt;
    }
  }
  
  public void SetAlign(int paramInt1, int paramInt2)
  {
    this.alignX = paramInt1;
    this.alignY = paramInt2;
    switch (paramInt1)
    {
    case 37: 
      this.offsetX = 0.0F;
      break;
    case 3: 
      this.offsetX = (-this.sizeX / 2.0F);
      break;
    case 39: 
      this.offsetX = (-this.sizeX);
    }
    switch (paramInt2)
    {
    case 102: 
      this.offsetY = 0.0F;
      break;
    case 3: 
      this.offsetY = (this.sizeY / 2.0F);
      break;
    case 101: 
      this.offsetY = this.sizeY;
      break;
    case 0: 
      this.offsetY = (this.normal.descent() * this.fontSize);
    }
  }
  
  public void SetRotation(float paramFloat)
  {
    this.rotation = paramFloat;
  }
  
  public void draw()
  {
    if ((this.posX == -1) || (this.posY == -1)) {
      return;
    }
    this.applet.pushMatrix();
    this.applet.translate(this.posX, this.posY);
    this.applet.rotate(this.rotation);
    this.applet.textAlign(37);
    float f = 0.0F;
    for (int i = 0; i < this.str.length(); i++)
    {
      char c1 = this.str.charAt(i);
      if ((c1 == '^') || (c1 == '_'))
      {
        char c2 = c1;
        this.applet.textFont(this.small, this.smallSize);
        for (;;)
        {
          i++;
          if ((i >= this.str.length()) || ((c1 = this.str.charAt(i)) == ' ')) {
            break;
          }
          this.applet.text(c1, this.offsetX + f, this.offsetY + (c2 == '^' ? -this.smallSize / 2.0F : this.smallSize / 4.0F));
          f += ((Float)this.width.get(Character.valueOf(c1))).floatValue() * this.smallSize;
        }
      }
      else
      {
        this.applet.textFont(this.normal, this.fontSize);
        this.applet.text(c1, this.offsetX + f, this.offsetY);
        f += ((Float)this.width.get(Character.valueOf(c1))).floatValue() * this.fontSize;
      }
    }
    this.applet.popMatrix();
  }
  
  public void draw(int paramInt1, int paramInt2)
  {
    this.applet.pushMatrix();
    this.applet.translate(paramInt1, paramInt2);
    this.applet.rotate(this.rotation);
    this.applet.textAlign(37);
    float f = 0.0F;
    for (int i = 0; i < this.str.length(); i++)
    {
      char c1 = this.str.charAt(i);
      if ((c1 == '^') || (c1 == '_'))
      {
        char c2 = c1;
        this.applet.textFont(this.small, this.smallSize);
        for (;;)
        {
          i++;
          if ((i >= this.str.length()) || ((c1 = this.str.charAt(i)) == ' ')) {
            break;
          }
          this.applet.text(c1, this.offsetX + f, this.offsetY + (c2 == '^' ? -this.smallSize / 2.0F : this.smallSize / 4.0F));
          f += ((Float)this.width.get(Character.valueOf(c1))).floatValue() * this.smallSize;
        }
      }
      else
      {
        this.applet.textFont(this.normal, this.fontSize);
        this.applet.text(c1, this.offsetX + f, this.offsetY);
        f += ((Float)this.width.get(Character.valueOf(c1))).floatValue() * this.fontSize;
      }
    }
    this.applet.popMatrix();
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/TextLabel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */