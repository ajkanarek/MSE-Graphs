class Particle
{
  float m = 1.0F;
  float[] pos = { 0.0F, 0.0F, 0.0F };
  float[] vel = { 0.0F, 0.0F, 0.0F };
  int[] fixed = { 0, 0, 0 };
  float e = 0.0F;
  public float dt = 0.005F;
  
  Particle(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    this.pos[0] = paramFloat1;
    this.pos[1] = paramFloat2;
    this.m = paramFloat3;
  }
  
  Particle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    this.pos[0] = paramFloat1;
    this.pos[1] = paramFloat2;
    this.pos[2] = paramFloat3;
    this.m = paramFloat4;
  }
  
  Particle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
  {
    this.pos[0] = paramFloat1;
    this.pos[1] = paramFloat2;
    this.m = paramFloat3;
    this.vel[0] = paramFloat4;
    this.vel[1] = paramFloat5;
  }
  
  Particle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7)
  {
    this.pos[0] = paramFloat1;
    this.pos[1] = paramFloat2;
    this.pos[2] = paramFloat3;
    this.m = paramFloat4;
    this.vel[0] = paramFloat5;
    this.vel[1] = paramFloat6;
    this.vel[2] = paramFloat7;
  }
  
  void update()
  {
    this.pos[0] += this.dt * this.vel[0];
    this.pos[1] += this.dt * this.vel[1];
    this.pos[2] += this.dt * this.vel[2];
    this.e = (0.5F * this.m * (float)Math.sqrt(this.vel[0] * this.vel[0] + this.vel[1] * this.vel[1] + this.vel[2] * this.vel[2]));
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/Particle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */