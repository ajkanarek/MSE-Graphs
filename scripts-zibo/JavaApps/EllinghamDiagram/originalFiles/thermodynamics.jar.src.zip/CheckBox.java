import processing.core.PApplet;

public class CheckBox
{
  PApplet applet;
  String str;
  int posX;
  int posY;
  int sizeX;
  int sizeY;
  TextLabel label;
  public boolean checked;
  boolean prevStatus;
  
  public CheckBox(PApplet paramPApplet, int paramInt1, int paramInt2, String paramString)
  {
    this.applet = paramPApplet;
    this.label = new TextLabel(paramPApplet, paramString, paramInt1 + 25, paramInt2);
    this.label.SetAlign(37, 101);
    this.posX = paramInt1;
    this.posY = paramInt2;
    this.sizeX = (25 + (int)this.label.sizeX);
    this.sizeY = 15;
  }
  
  public boolean over()
  {
    return (this.applet.mouseX >= this.posX) && (this.applet.mouseX < this.posX + this.sizeX) && (this.applet.mouseY >= this.posY) && (this.applet.mouseY < this.posY + this.sizeY);
  }
  
  public void update()
  {
    boolean bool = (over()) && (this.applet.mousePressed);
    if ((!this.prevStatus) && (bool)) {
      this.checked = (!this.checked);
    }
    this.prevStatus = bool;
  }
  
  public void display()
  {
    this.applet.noStroke();
    this.applet.fill(200.0F, 200.0F, 200.0F);
    this.applet.rect(this.posX, this.posY, this.sizeX, this.sizeY);
    this.applet.stroke(0);
    if (this.checked) {
      this.applet.fill(200.0F, 0.0F, 0.0F);
    } else {
      this.applet.fill(200.0F, 200.0F, 200.0F);
    }
    this.applet.rectMode(0);
    this.applet.rect(this.posX, this.posY, this.sizeY, this.sizeY);
    this.applet.fill(0);
    this.label.draw();
  }
}


/* Location:              /Users/AndrewKanarek/Desktop/MICHIGAN/KiefferWork/scripts-zibo/JavaApps/EllinghamDiagram/thermodynamics.jar!/CheckBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */